package day1;

public class AmazonSignup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
