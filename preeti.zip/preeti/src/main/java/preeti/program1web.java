package preeti;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class program1web {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\\\\\\\chromedriver-win64 (4)\\\\\\\\chromedriver-win64/chromedriver.exe"); 
		WebDriver preeti = new ChromeDriver();
		preeti.get("http://www.javatpoint.com/");
		preeti.manage().window().maximize();  // After loading maximize the page 
        
	}
    }


