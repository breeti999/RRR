package preeti;

public class P1 {
	static void main(String args[])
	{
		System.out.println(2+7);
	}

}
