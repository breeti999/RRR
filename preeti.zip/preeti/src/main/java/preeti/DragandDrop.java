package preeti;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

        public class DragandDrop{

	    public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		 System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe"); 
		 WebDriver preeti = new ChromeDriver();
		 preeti.manage().window().maximize(); 
         preeti.get("http://www.dhtmlgoodies.com/scripts/drag-drop-custom/demo-drag-drop-3.html");
         Actions act = new Actions(preeti);
         
         // preeti.switchTo().frame(0);
        
         WebElement source =  preeti.findElement(By.xpath("  //*[@id=\'box6\']"));
         WebElement destination =  preeti.findElement(By.xpath("//*[@id=\'box106\']"));
         act.clickAndHold(source).moveToElement(destination).release().build().perform(); //it is used for just hold
         Thread.sleep(5000);
         
         WebElement source1 =  preeti.findElement(By.xpath("//*[@id=\"box7\"]"));
         WebElement destination1 =  preeti.findElement(By.xpath("//*[@id=\"box107\"]"));
         act.clickAndHold(source1).moveToElement(destination1).release().build().perform();
         Thread.sleep(5000);
         
         WebElement source2 =  preeti.findElement(By.xpath("//*[@id=\"box1\"]"));
         WebElement destination2 =  preeti.findElement(By.xpath("//*[@id=\"box101\"]"));
         act.dragAndDrop(source2, destination2).moveToElement(destination2).release().build().perform(); // it used for drag,drop and release
         }
	     }
