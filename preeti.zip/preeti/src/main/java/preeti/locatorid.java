package preeti;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

    public class locatorid {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\\\\\\\chromedriver-win64 (4)\\\\\\\\chromedriver-win64/chromedriver.exe"); 
		WebDriver preeti = new ChromeDriver();
		//preeti.get("http://www.javatpoint.com/");
	//preeti.get("https://accounts.google.com/v3/signin/identifier?dsh=S-519364575%3A1685361321617840&continue=https%3A%2F%2Fmail.google.com%2Fmail%2Fu%2F0%2F&emr=1&followup=https%3A%2F%2Fmail.google.com%2Fmail%2Fu%2F0%2F&ifkv=Af_xneGtMO_4NGueoklWCsiVTnn4Yc9Mylrar9O4QO3cVK2Khinq_5nUQJ_bCNVgKszjcNfNFxJb-Q&osid=1&passive=1209600&service=mail&flowName=GlifWebSignIn&flowEntry=ServiceLogin/");
		preeti.get("https://www.linkedin.com/login/");
		//preeti.manage().window().maximize();  // After loading maximize the page 
        preeti.findElement(By.id("username")).sendKeys("8764876238746"); // use of send keys is kept in the place of empty. Inspect see id in the element Use id place value
		//preeti.findElement(By.name("pass")).sendKeys("password"); // use name place value after inspect & see in the element
		//preeti.findElement(By.className("inputtext")).sendKeys("battala@gmail.com"); //Inspect use className value what className is use that one.
		//preeti.findElement(By.tagName("input")).sendKeys("7577587");
		//preeti.findElement(By.linkText("Forgotten account?")).click();
		//preeti.findElement(By.partialLinkText("Forgotten")).click();
		//preeti.findElement(By.cssSelector("#username")).sendKeys("7577587");
		//preeti.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("123456789");
		//preeti.findElement(By.xpath("//*[@id=\"join_now\"]")).click(); // extra this one automatically redirect the page to which link you given (join)
	    }
        }

    
