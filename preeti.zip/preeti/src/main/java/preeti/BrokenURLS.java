package preeti;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class BrokenURLS {

	public static void main(String[] args) {
		
		 System.setProperty("webdriver.chrome.driver", "C:\\\\\\\\chromedriver-win64 (4)\\\\\\\\chromedriver-win64/chromedriver.exe"); 
		 WebDriver preeti = new ChromeDriver();
		 preeti.manage().window().maximize(); 
         preeti.get("https://demo.guru99.com/selenium/newtours/");
         List<WebElement> links = preeti.findElements(By.tagName("a"));
         int size = links.size();
         System.out.println(size);
         
        
	} 

}
