package preeti;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

            public class Handlingtextboxes {

	        public static void main(String[] args) throws InterruptedException {
		    System.setProperty("webdriver.chrome.driver", "C:\\\\\\\\chromedriver-win64 (4)\\\\\\\\chromedriver-win64/chromedriver.exe"); 
			WebDriver preeti = new ChromeDriver();
			preeti.manage().window().maximize();
			preeti.get("file:///C:/Users/battala.preeti/Documents/seleniumchecktextprogram2.html");
			preeti.findElement(By.id("name")).sendKeys("preeti");
			preeti.findElement(By.id("pwd")).sendKeys("sweeti");
		//	Thread.sleep(5000);
	    //	preeti.findElement(By.id("name")).clear();
		//    System.out.println(preeti.findElement(By.id("name")).getAttribute("value"));
		//    System.out.println(preeti.findElement(By.id("pwd")).getAttribute("type"));
			
			// or //
		    
		   // WebElement name=preeti.findElement(By.id("name")); // created one webelement store the name
			//name.sendKeys("preeti");
			//preeti.findElement(By.id("pwd")).sendKeys("sweeti");
	       // System.out.println(name.getAttribute("value"));
	       // System.out.println(preeti.findElement(By.id("pwd")).getAttribute("type"));
			
	}
	}
