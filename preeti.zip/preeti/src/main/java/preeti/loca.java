package preeti;

public class loca {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
