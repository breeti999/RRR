package preeti;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

         public class keys {

	     public static void main(String[] args) throws InterruptedException {
		
		  System.setProperty("webdriver.chrome.driver", "C:\\\\\\\\chromedriver-win64 (4)\\\\\\\\chromedriver-win64/chromedriver.exe"); 
		  WebDriver preeti = new ChromeDriver();
		  preeti.manage().window().maximize();
		 // preeti.get("file:///C:/Users/battala.preeti/Documents/handlingAlerts.html"); 
		  preeti.get("https://jqueryui.com/slider/"); 
		  Actions act = new Actions(preeti);
		  
          //WebElement name = preeti.findElement(By.id("name"));
          //Thread.sleep(5000);
         // act.keyDown(name, Keys.SHIFT).sendKeys("preetiyadav").build().perform();
         // act.keyUp(Keys.SHIFT);
         // act.keyDown(name, Keys.F5).sendKeys("preetiyadav").build().perform(); 
          
          
          WebElement source =  preeti.findElement(By.xpath("//*[@id=\"slider\"]/span"));
          act.dragAndDropBy(source, 300, 0).click().build().perform();
          
          
         }
         }
