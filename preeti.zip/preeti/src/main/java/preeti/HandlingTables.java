package preeti;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingTables {

	public static void main(String[] args) {

        System.setProperty("webdriver.chrome.driver", "C:\\\\\\\\chromedriver-win64 (4)\\\\\\\\chromedriver-win64/chromedriver.exe"); 
		WebDriver preeti = new ChromeDriver();
		preeti.manage().window().maximize();
		preeti.get("file:///C:/Users/battala.preeti/Documents/HandlingTabes.html");
		WebElement table = preeti.findElement(By.xpath("/html/body/table"));
		
    	List <WebElement> rows= table.findElements(By.xpath("/html/body/table/tbody/tr")); // only put tr rows count don't take tr1. just copy the x path and paste it here
    //1 	System.out.println(rows.size()); // here you print the rows on eclipse 
    	
		int rowcount=rows.size();
    	List <WebElement> columns= table.findElements(By.xpath("/html/body/table/tbody/tr[1]/th")); // only put th columns count, Take x path on right click on header like mail
    	//2 System.out.println(columns.size());
    	
        int columncount=columns.size();
    	
    	List <WebElement> cells= table.findElements(By.xpath("/html/body/table/tbody/tr/td"));
    	System.out.println(cells.size());  // cells count 
    	
    	 
    	 
   // s 	for(int i=1;i<=1;i++)
   // 	{
   //  		for(int j=1;j<=columncount;j++)
    //		{
   // 			System.out.print(table.findElement(By.xpath("/html/body/table/tbody/tr["+i+"]/th["+j+"]")).getText()+" "); // in lineno 26 i=1; in line 30 lo td replace th. for headers only
    //		}
    //		System.out.println(); // after printing go to nextline
    //	}
    //	for(int i=2;i<=rowcount;i++)
    //	{
    //		for(int j=1;j<=columncount;j++)
    //		{
    //			System.out.print(table.findElement(By.xpath("/html/body/table/tbody/tr["+i+"]/td["+j+"]")).getText()+" "); 
    //		
    	}
    //		System.out.println();
    //	}
    	
	// s }
}