package preeti;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

   public class Commands {

	public static void main(String[] args) throws InterruptedException
	{
		
        System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe"); 
		WebDriver preeti = new ChromeDriver();
		preeti.manage().window().maximize();
		
		// BROWSER COMMANDS //
		
		preeti.get("https://www.linkedin.com/login/"); //1
		//preeti.get("https://www.linkedin.com/signup/cold-join");// this join page only close 
		System.out.println(preeti.getTitle());
		System.out.println(preeti.getCurrentUrl());
		//preeti.findElement(By.xpath("//*[@id=\"join_now\"]")).click();
		//preeti.close();
		//preeti.quit(); // all close page
		
		// navigation commands //
		
		preeti.navigate().to("https://accounts.google.com/v3/signin/identifier?dsh=S2131170906%3A1685450932864782&continue=https%3A%2F%2Fmail.google.com%2Fmail%2Fu%2F0%2F&emr=1&followup=https%3A%2F%2Fmail.google.com%2Fmail%2Fu%2F0%2F&ifkv=Af_xneF6MZCVvs7rGXHxZJfQg6ZIbD60lik-aHRkUKqzYlzLbXvppnF32B6oglV2yclDfFw5RgdvJA&osid=1&passive=1209600&service=mail&flowName=GlifWebSignIn&flowEntry=ServiceLogin");
	    //2. navigate to open the webpage, change from one web page to another web page
		Thread.sleep(5000); // It is used to time gap purpose
		//preeti.navigate().back(); // change linked to gmail and again shift to gmail to linked 
	//	Thread.sleep(5000);
    	//preeti.navigate().forward(); // again forward from gamil to linkedLn
		//preeti.navigate().refresh(); // Page refresh
		//preeti.findElement(By.id("id23")).sendKeys("keys.F5"); // In keyboard press the F5 button, then refresh the page
	
	}
    }