package preeti;

import java.util.Iterator;
import java.util.Set;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleMultipleTabs {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\\\\\\\chromedriver-win64 (4)\\\\\\\\chromedriver-win64/chromedriver.exe"); 
		WebDriver preeti = new ChromeDriver();
		preeti.get("https://www.hyrtutorials.com/p/window-handles-practice.html"); 
		preeti.manage().window().maximize();
		
		// preeti.findElement(By.id("name")).sendKeys("Preetisuperwomen");
	    //Thread.sleep(5000);
		preeti.findElement(By.xpath("//*[@id=\"newTabsBtn\"]")).click(); // open multiple tabs
		//  preeti.findElement(By.xpath("//*[@id=\"newTabBtn\"]")).click(); // open one new tab 
		
	//	preeti.findElement(By.xpath("//*[@id=\"newWindowBtn\"]")).click(); // open one window
	//	preeti.findElement(By.xpath("//*[@id=\"newWindowsBtn\"]")).click(); // open multiple windows
	//	preeti.findElement(By.xpath("//*[@id=\"newTabsWindowsBtn\"]")).click(); // open mutiple windows and tabs
	//	preeti.close();
		
		
		

		preeti.findElement(By.id("confirmBox")).click();
    Thread.sleep(5000);
		preeti.switchTo().alert().accept();  // alerts will do in that page only, not take too many urls for multiple tab
//		
		
		
		//Thread.sleep(5000);
//		preeti.manage().window().maximize();
//		preeti.findElement(By.xpath("//button[@id='newWindowsBtn']")).click();
//		Thread.sleep(5000);
		//preeti.get("https://www.hyrtutorials.com/p/alertsdemo.html"); 
	//	preeti.findElement(By.linkText("Click me")).click();
		//preeti.findElement(By.id("confirmBox")).click(); 
	//	preeti.switchTo().alert().accept();
//		//preeti.findElement(By.xpath("//*[@id=\"main\"]/div[3]/div/div[1]/a[3]")).click();

		
//			Set<String> windows = preeti.getWindowHandles();
//		    int size = windows.size();
//	        String ids[] = new String[size]; //storing purpose  i created array
//	        Iterator<String> itr = windows.iterator(); // it will read each tab, taken from getwindows
//	
//	        //System.out.println(windows.size());
//	        for(int i=0;i<size;i++)
//	        {
//		    ids[i] = itr.next(); // store each value
//		    System.out.println("Parent window : " +preeti.getTitle());
//		    preeti.switchTo().window(ids[2]);
//		    
//		    System.out.println("Child window : " +preeti.getTitle());
//	}

	}

}
