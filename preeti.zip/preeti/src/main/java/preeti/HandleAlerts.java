package preeti;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleAlerts {

	         public static void main(String[] args) throws InterruptedException {
		      // TODO Auto-generated method stub
		      System.setProperty("webdriver.chrome.driver", "C:\\\\\\\\chromedriver-win64 (4)\\\\\\\\chromedriver-win64/chromedriver.exe"); 
			  WebDriver preeti = new ChromeDriver();
			  preeti.manage().window().maximize();
			  preeti.get("file:///C:/Users/battala.preeti/Documents/handlingAlerts.html"); // html run and take the path In the output we get the path
	      preeti.findElement(By.id("btn1")).click(); // 1 alert box
	         Thread.sleep(5000);
	
	     preeti.switchTo().alert().accept(); // 1 accept the page 
	 //         preeti.findElement(By.id("btn2")).click();  //2,3 btn2 conform box
	  //        preeti.switchTo().alert().dismiss(); // cancel the page //2
	  //        System.out.println(preeti.switchTo().alert().getText());  //3
	   //       preeti.findElement(By.id("btn3")).click(); //? and @
	   //       preeti.switchTo().alert().sendKeys("preeti"); // ? prompt alert btn 3 value insert the preeti in that box
	     //     preeti.switchTo().alert().accept();// ?
	          
	    //      Alert alertbox=preeti.switchTo().alert(); // @ created alertbox variable for use of reduce code.
	     //     alertbox.sendKeys("preeti"); //@
	     //     alertbox.accept(); //@ in ui print hi preeti . how are you 
	          
	          preeti.findElement(By.id("file")).sendKeys("C:\\Users\\battala.preeti\\Desktop\\Teamleaderlist.Docx"); // upload the the file automatically
             }
             }

// issue was no code for this for practical, he created own html page, i am also created but that is not correct