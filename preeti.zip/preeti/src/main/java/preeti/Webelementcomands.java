package preeti;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Webelementcomands {

	    public static void main(String[] args) throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", "C:\\\\\\\\chromedriver-win64 (4)\\\\\\\\chromedriver-win64/chromedriver.exe"); 
		WebDriver preeti = new ChromeDriver();
		preeti.manage().window().maximize();
		
	//1	preeti.get("https://www.linkedin.com/login/"); 
		preeti.get("file:///C:/Users/battala.preeti/Documents/htmlselenium1.html"); // 2 i am created html file
	//1	preeti.findElement(By.xpath("//*[@id=\"heading\"]")).sendKeys("8764876238746");
	//1    preeti.findElement(By.xpath(" //*[@id=\"username\"]")).sendKeys("8764876238746"); // what you entered value displayed in the classpath id
	//1	Thread.sleep(5000);
	//1	preeti.findElement(By.xpath(" //*[@id=\"username\"]")).clear(); // clear the xpath data
	//2	preeti.findElement(By.xpath("//*[@id=\"heading\"]")).getText(); like x path and not print.
	//	System.out.println(preeti.findElement(By.id("heading")).getText()); // 2 what you given id name that text data read and print in the output means in eclipse only
	//    System.out.println(preeti.findElement(By.id("JAVA")).isDisplayed()); // 2 if the id java is there in current page print true in eclipse otherwise false
	//    System.out.println(preeti.findElement(By.id("b2")).isEnabled());
	    System.out.println(preeti.findElement(By.id("male")).isSelected()); 
	}
    }
