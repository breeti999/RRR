package preeti;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingIFrames {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 System.setProperty("webdriver.chrome.driver", "C:\\\\\\\\chromedriver-win64 (4)\\\\\\\\chromedriver-win64/chromedriver.exe"); 
			WebDriver preeti = new ChromeDriver();
			preeti.manage().window().maximize();
			preeti.get("https://www.javatpoint.com/");
			// String heading=preeti.findElement(By.xpath("//*[@id=\"righthome\"]/h2[1]")).getText(); // line no 15 & 16 same gettext use read the data
          //  System.out.println(heading);
            
       //     int framecount = preeti.findElements(By.tagName("iframe")).size(); // here tag name is iframe(after inspect see the tag name)
       //     System.out.println(framecount); // 18 & 19 same  beacuse no frames. that's why print the 0
           
            preeti.switchTo().frame(0);   // 21 to 23 same frame 0 means first webpage xpath display here, whatever frame we want that heading is display here that's why used switchTo
            String heading = preeti.findElement(By.xpath("//*[@id=\1\"] ")).getText(); // take main heading xpath (xpath default petta)
            System.out.println(heading);
            
            preeti.switchTo().defaultContent();
            
            preeti.switchTo().frame("iframe1");
            String heading2 = preeti.findElement(By.xpath("//*[@id=\1\"] ")).getText();
            System.out.println(heading2); // 21 to 29 same 
            
	}

}
