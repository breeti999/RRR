package preeti;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Contextrightclick {

	public static void main(String[] args) throws InterruptedException {
		 System.setProperty("webdriver.chrome.driver", "C:\\\\\\\\chromedriver-win64 (4)\\\\\\\\chromedriver-win64/chromedriver.exe"); 
		 WebDriver preeti = new ChromeDriver();
		 preeti.manage().window().maximize(); 
         preeti.get("https://swisnl.github.io/jQuery-contextMenu/demo.html");
         Actions act = new Actions(preeti);
         Thread.sleep(2000);
         WebElement button = preeti.findElement(By.xpath("/html/body/div/section/div/div/div/p/span"));
         act.contextClick(button).build().perform();
         act.moveToElement(preeti.findElement(By.xpath("/html/body/ul/li[5]"))).click().build().perform();
       
	}

}
 