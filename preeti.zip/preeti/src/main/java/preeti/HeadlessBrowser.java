package preeti;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class HeadlessBrowser {

	public static void main(String[] args) {
		// HtnlUnitDriver

       //		WebDriver preeti = new HtmlUnitDriver(); // here we need to add extra jar files 2, link https://github.com/SeleniumHQ/htmlunit-driver/releases
       		
		// ChromeDriver
		
		ChromeOptions option = new ChromeOptions(); // everything run in background
		option.addArguments("--headless");  // or option.setHeadless(true);
		WebDriver preeti = new ChromeDriver(option);
		
		
		
		preeti.manage().window().maximize();
		preeti.get("file:///C:/Users/battala.preeti/Documents/htmlselenium1.html");
		System.out.println(preeti.getCurrentUrl());
		System.out.println(preeti.getTitle()); // This time not opened page and directly print(current url and title) the output in eclipse
		

	}

}
