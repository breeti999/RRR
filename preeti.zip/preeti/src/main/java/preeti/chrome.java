package preeti;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class chrome {
	
	public static void main(String[] args )
	{
		System.setProperty("webdriver.chrome.driver", "C:\\\\\\\\chromedriver-win64 (4)\\\\\\\\chromedriver-win64/chromedriver.exe");
		//WebDriverManager.chromedriver().setup();
		WebDriver preeti = new ChromeDriver();
		preeti.navigate().to("http://www.javatpoint.com/");
		  
	}

}
