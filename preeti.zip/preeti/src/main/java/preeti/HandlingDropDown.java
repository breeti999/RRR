package preeti;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HandlingDropDown {

	public static void main(String[] args) throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", "C:\\\\\\\\chromedriver-win64 (4)\\\\\\\\chromedriver-win64/chromedriver.exe"); 
		WebDriver preeti = new ChromeDriver();
		preeti.manage().window().maximize();
		preeti.get("file:///C:/Users/battala.preeti/Documents/handlingdropdown.html");
		Select dropdown1=new Select(preeti.findElement(By.name("country"))); //select is used because of group of elements dropdown
		//dropdown1.selectByIndex(3);
		//dropdown1.selectByValue("India srilanka japan");
		//dropdown1.selectByVisibleText("India srilanka japan");
		//String list=dropdown1.getOptions(); // At the showing error so we just mouse over the error.list not convert to string that's why use list
		List<WebElement> list1=dropdown1.getOptions();
		int size=list1.size(); // store size value in size variable
		System.out.println(size); // size print
	//1	for(int i = 0;i<size;i++)
		{
	//1		String optValue=list1.get(i).getText();
	//1		System.out.println(optValue);  //line no 24 to 30 print the all the counties
			
			System.out.println(list1.get(3).getText()); // particularly in index 3 value print in eclipse
			
		}
		
		}
        }
