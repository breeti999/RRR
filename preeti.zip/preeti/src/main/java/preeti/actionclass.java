package preeti;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class actionclass {

	public static void main(String[] args) {
		 System.setProperty("webdriver.chrome.driver", "C:\\\\\\\\chromedriver-win64 (4)\\\\\\\\chromedriver-win64/chromedriver.exe"); 
		  WebDriver preeti = new ChromeDriver();
		  preeti.manage().window().maximize(); 
          preeti.get("https://demo.automationtesting.in/Register.html");
          
          //MOVETOELEMENT//
          
          
          
          Actions act = new Actions(preeti); 
          WebElement element1 =  preeti.findElement(By.xpath("//*[@id=\'header\']/nav/div/div[2]/ul/li[6]/a"));
          WebElement element2 =  preeti.findElement(By.xpath("//*[@id=\'header\']/nav/div/div[2]/ul/li[6]/ul/li[1]/a"));
          WebElement element3= preeti.findElement(By.xpath("//*[@id=\"header\"]/nav/div/div[2]/ul/li[6]/ul/li[1]/ul/li[2]/a"));
//          act.moveToElement(element1).build().perform();
//          act.moveToElement(element2).build().perform();
//          act.moveToElement(element3).click().build().perform();
          act.moveToElement(element1).moveToElement(element2).moveToElement(element3).click().build().perform();
          
          
		  
	}

}
