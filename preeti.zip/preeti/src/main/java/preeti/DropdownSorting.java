package preeti;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropdownSorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   System.setProperty("webdriver.chrome.driver", "C:\\chromedriver-win64 (4)\\chromedriver-win64/chromedriver.exe"); 
		   
		 
			WebDriver preeti = new ChromeDriver();
			preeti.manage().window().maximize();
			
			preeti.get("file:///C:/Users/battala.preeti/Documents/handlingdropdown.html");
			WebElement dropdown = preeti.findElement(By.id("country"));
			Select se = new Select(dropdown); // or Select se = new Select(preeti.findElement(By.id("country")));
			
			List<WebElement> options = se.getOptions();
			List values = new ArrayList();
			for(WebElement opt:options)
			{ 
				values.add(opt.getText());
			}
			System.out.println("Original Options :"+values);
			
			List tempvalues = new ArrayList(values);
			Collections.sort(tempvalues);   // lists lo values sort cheyalante use the sort. sort in collections
			//System.out.println(tempvalues); 1 to 37 same 
			
	        boolean sort=values.equals(tempvalues);
	        
	        if(sort)
	        {
	        	System.out.println("Dropdown is sorted");	
	        }
	        else
	        {
	        	System.out.println("Dropdown is not sorted");
	}
	}

}
